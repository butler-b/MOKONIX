# MOKONIX

@start code input@

sudo apt  install docker-compose -y

sudo usermod -aG docker $USER
newgrp docker

